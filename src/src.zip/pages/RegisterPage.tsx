import { Alert, Box, Button, Container, Paper, Stack, TextField, Typography } from "@mui/material";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useAuth } from "../auth/AuthContext";
import { useNavigate, Link as RouterLink } from "react-router-dom";

const currentYear = new Date().getFullYear();

const registerSchema = z.object({
    email: z.string().min(1, "Укажи почту").email("Неверный формат почты"),
    username: z.string().min(3, "Минимум 3 символа").max(24, "Максимум 24 символа"),
    birthYear: z.coerce
        .number()
        .int("Год должен быть целым")
        .min(1900, "Слишком старый год 🙂")
        .max(currentYear - 6, "Слишком рано для регистрации"),
    password: z.string().min(8, "Пароль минимум 8 символов"),
});

type RegisterForm = z.infer<typeof registerSchema>;

export default function RegisterPage() {
    const auth = useAuth();
    const nav = useNavigate();

    const {
        register,
        handleSubmit,
        formState: { errors, isSubmitting },
    } = useForm<RegisterForm>({
        resolver: zodResolver(registerSchema),
        defaultValues: {
            email: "",
            username: "",
            birthYear: currentYear - 18,
            password: "",
        },
    });

    const [serverError, setServerError] = useState<string | null>(null);

    async function onSubmit(values: RegisterForm) {
        setServerError(null);
        try {
            await auth.register(values);
            nav("/profile");
        } catch (e) {
            setServerError(e instanceof Error ? e.message : "Ошибка регистрации");
        }
    }

    return (
        <Container maxWidth="sm" sx={{ py: 6 }}>
            <Paper sx={{ p: { xs: 2.5, md: 3.5 }, borderRadius: 3 }}>
                <Stack spacing={2}>
                    <Box>
                        <Typography variant="h5" sx={{ fontWeight: 900 }}>
                            Регистрация
                        </Typography>
                        <Typography sx={{ color: "text.secondary" }}>
                            Создай аккаунт StudyBytes
                        </Typography>
                    </Box>

                    {serverError && <Alert severity="error">{serverError}</Alert>}

                    <Stack spacing={1.6} component="form" onSubmit={handleSubmit(onSubmit)}>
                        <TextField
                            label="Email"
                            type="email"
                            autoComplete="email"
                            {...register("email")}
                            error={!!errors.email}
                            helperText={errors.email?.message}
                            fullWidth
                        />

                        <TextField
                            label="Имя пользователя"
                            autoComplete="username"
                            {...register("username")}
                            error={!!errors.username}
                            helperText={errors.username?.message}
                            fullWidth
                        />

                        <TextField
                            label="Год рождения"
                            type="number"
                            {...register("birthYear")}
                            error={!!errors.birthYear}
                            helperText={errors.birthYear?.message}
                            fullWidth
                        />

                        <TextField
                            label="Пароль"
                            type="password"
                            autoComplete="new-password"
                            {...register("password")}
                            error={!!errors.password}
                            helperText={errors.password?.message}
                            fullWidth
                        />

                        <Button
                            type="submit"
                            variant="contained"
                            size="large"
                            disabled={isSubmitting}
                            sx={{ borderRadius: 999, py: 1.2, fontWeight: 900 }}
                        >
                            Создать аккаунт
                        </Button>

                        <Typography variant="body2" sx={{ color: "text.secondary" }}>
                            Уже есть аккаунт?{" "}
                            <Button component={RouterLink} to="/login" variant="text" sx={{ p: 0, minWidth: "auto" }}>
                                Войти
                            </Button>
                        </Typography>
                    </Stack>
                </Stack>
            </Paper>
        </Container>
    );
}

import { useState } from "react";
