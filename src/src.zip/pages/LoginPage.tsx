import { Alert, Box, Button, Container, Paper, Stack, TextField, Typography } from "@mui/material";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useAuth } from "../auth/AuthContext";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

const loginSchema = z.object({
    email: z.string().min(1, "Укажи почту").email("Неверный формат почты"),
    password: z.string().min(1, "Введи пароль"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function LoginPage() {
    const auth = useAuth();
    const nav = useNavigate();

    const {
        register,
        handleSubmit,
        formState: { errors, isSubmitting },
    } = useForm<LoginForm>({
        resolver: zodResolver(loginSchema),
        defaultValues: { email: "", password: "" },
    });

    const [serverError, setServerError] = useState<string | null>(null);

    async function onSubmit(values: LoginForm) {
        setServerError(null);
        try {
            await auth.login(values);
            nav("/");
        } catch (e) {
            setServerError(e instanceof Error ? e.message : "Ошибка входа");
        }
    }

    return (
        <Container maxWidth="sm" sx={{ py: 6 }}>
            <Paper sx={{ p: { xs: 2.5, md: 3.5 }, borderRadius: 3 }}>
                <Stack spacing={2}>
                    <Box>
                        <Typography variant="h5" sx={{ fontWeight: 900 }}>
                            Вход
                        </Typography>
                        <Typography sx={{ color: "text.secondary" }}>
                            Добро пожаловать обратно
                        </Typography>
                    </Box>

                    {serverError && <Alert severity="error">{serverError}</Alert>}

                    <Stack spacing={1.6} component="form" onSubmit={handleSubmit(onSubmit)}>
                        <TextField
                            label="Email"
                            type="email"
                            autoComplete="email"
                            {...register("email")}
                            error={!!errors.email}
                            helperText={errors.email?.message}
                            fullWidth
                        />

                        <TextField
                            label="Пароль"
                            type="password"
                            autoComplete="current-password"
                            {...register("password")}
                            error={!!errors.password}
                            helperText={errors.password?.message}
                            fullWidth
                        />

                        <Button
                            type="submit"
                            variant="contained"
                            size="large"
                            disabled={isSubmitting}
                            sx={{ borderRadius: 999, py: 1.2, fontWeight: 900 }}
                        >
                            Войти
                        </Button>
                    </Stack>
                </Stack>
            </Paper>
        </Container>
    );
}
