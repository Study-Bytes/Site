import { AppBar, Toolbar, Typography, Button, Stack, Box } from "@mui/material";
import SchoolRoundedIcon from "@mui/icons-material/SchoolRounded";
import { Link as RouterLink, useLocation } from "react-router-dom";

export default function Navbar() {
    const location = useLocation();

    const isAuthPage = location.pathname === "/login" || location.pathname === "/signup";

    return (
        <AppBar
            position="fixed"
            elevation={0}
            color="transparent"
            sx={{
                borderBottom: "1px solid rgba(16, 24, 40, 0.08)",
                backgroundColor: "rgba(246, 247, 251, 0.72)",
                backdropFilter: "blur(14px)",
            }}
        >
            <Toolbar sx={{ minHeight: 72 }}>
                <Stack direction="row" spacing={1.2} alignItems="center">
                    <SchoolRoundedIcon />
                    <Typography
                        component={RouterLink}
                        to="/"
                        sx={{
                            textDecoration: "none",
                            color: "text.primary",
                            fontWeight: 900,
                            letterSpacing: 0.2,
                        }}
                    >
                        StudyBytes
                    </Typography>
                    <Button
                        component={RouterLink}
                        to="/teacher"
                        variant="text"
                        sx={{
                            ml: 2,
                            fontWeight: 800,
                            color: "text.secondary",
                            display: { xs: "none", sm: "inline-flex" },
                        }}
                    >
                        Кабинет преподавателя
                    </Button>
                </Stack>

                <Box sx={{ flexGrow: 1 }} />

                <Stack direction="row" spacing={1}>
                    <Button
                        component={RouterLink}
                        to="/login"
                        variant={isAuthPage ? "text" : "outlined"}
                        color="primary"
                    >
                        Войти
                    </Button>

                    <Button component={RouterLink} to="/signup" variant="contained" color="primary">
                        Регистрация
                    </Button>
                </Stack>
            </Toolbar>
        </AppBar>
    );
}
